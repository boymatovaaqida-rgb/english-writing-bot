# WriteUp Bot — Ishga tushirish yo'riqnomasi

## 1-qadam: Telegram token olish

1. Telegramda **@BotFather** ga boring
2. `/newbot` yuboring
3. Botingiz uchun nom yozing (masalan: `WriteUp Coach`)
4. Username yozing (masalan: `writeup_coach_bot`)
5. BotFather sizga **TOKEN** beradi — uni saqlab qo'ying
   Misol: `7123456789:AAHdqTcvCHhvQNqx29T_kcn6zECaz`

---

## 2-qadam: Anthropic API key olish

1. https://console.anthropic.com ga boring
2. Ro'yxatdan o'ting (bepul)
3. **API Keys** bo'limiga boring
4. **Create Key** bosing
5. Kalitni saqlab qo'ying
   Misol: `sk-ant-api03-...`

---

## 3-qadam: Railway.app da joylashtirish (BEPUL)

1. https://railway.app ga boring
2. GitHub akkauntingiz bilan kiring
3. **New Project** → **Deploy from GitHub repo** bosing
4. Agar GitHub yo'q bo'lsa:
   - GitHub.com da bepul akkaunt oching
   - New repository → `writeup-bot` deb nomlang
   - Barcha fayllarni yuklang (bot.py, requirements.txt, Procfile)

### Environment Variables qo'shish:
Railway loyihangizda → **Variables** bo'limiga boring:

| Key | Value |
|-----|-------|
| `TELEGRAM_TOKEN` | BotFather dan olgan tokeningiz |
| `ANTHROPIC_API_KEY` | Anthropic dan olgan kalitingiz |

---

## 4-qadam: Deploy

Variables qo'shilgach Railway avtomatik ishga tushiradi.
**Deploy** bo'limida yashil chiroq ko'rsangiz — bot tayyor! ✅

---

## Bot buyruqlari

| Buyruq | Vazifasi |
|--------|----------|
| `/start` | Botni boshlash |
| `/topic` | Yangi mavzu olish |
| `/type` | Yozish turini tanlash |
| `/idea` | G'oya olish |
| `/tips` | Maslahatlar |
| `/help` | Yordam |

Inglizcha matn yuborsangiz — bot avtomatik tekshiradi!

---

## Muammolar bo'lsa

- Bot javob bermasa → Railway da **Logs** ni tekshiring
- Token xato → BotFather dan yangi token oling
- API xato → Anthropic console da kredit borligini tekshiring
